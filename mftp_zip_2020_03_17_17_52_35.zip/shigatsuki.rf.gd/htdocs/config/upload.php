<?php return array (
  '/upload/.htaccess' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/.htaccess',
    'remotepath' => '/upload/.htaccess',
    'filesize' => 127,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/README.md' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/README.md',
    'remotepath' => '/upload/README.md',
    'filesize' => 2505,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/cache/README.md' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/cache/README.md',
    'remotepath' => '/upload/cache/README.md',
    'filesize' => 36,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/cache/cachedata.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/cache/cachedata.php',
    'remotepath' => '/upload/cache/cachedata.php',
    'filesize' => 105120348,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/config/README.md' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/config/README.md',
    'remotepath' => '/upload/config/README.md',
    'filesize' => 36,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/config/base.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/config/base.php',
    'remotepath' => '/upload/config/base.php',
    'filesize' => 2771,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/config/token.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/config/token.php',
    'remotepath' => '/upload/config/token.php',
    'filesize' => 2937,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/config/upload.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/config/upload.php',
    'remotepath' => '/upload/config/upload.php',
    'filesize' => 1888,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/controller/AdminController.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/controller/AdminController.php',
    'remotepath' => '/upload/controller/AdminController.php',
    'filesize' => 6434,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/controller/ImagesController.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/controller/ImagesController.php',
    'remotepath' => '/upload/controller/ImagesController.php',
    'filesize' => 1581,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/controller/IndexController.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/controller/IndexController.php',
    'remotepath' => '/upload/controller/IndexController.php',
    'filesize' => 5874,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/controller/UploadController.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/controller/UploadController.php',
    'remotepath' => '/upload/controller/UploadController.php',
    'filesize' => 6347,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/index.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/index.php',
    'remotepath' => '/upload/index.php',
    'filesize' => 2269,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/init.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/init.php',
    'remotepath' => '/upload/init.php',
    'filesize' => 3467,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/lib/Parsedown.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/lib/Parsedown.php',
    'remotepath' => '/upload/lib/Parsedown.php',
    'filesize' => 41273,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/lib/cache/filecache_.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/lib/cache/filecache_.php',
    'remotepath' => '/upload/lib/cache/filecache_.php',
    'filesize' => 770,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/lib/cache/memcache_.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/lib/cache/memcache_.php',
    'remotepath' => '/upload/lib/cache/memcache_.php',
    'filesize' => 649,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/lib/cache/redis_.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/lib/cache/redis_.php',
    'remotepath' => '/upload/lib/cache/redis_.php',
    'filesize' => 1223,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/lib/cache/secache_.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/lib/cache/secache_.php',
    'remotepath' => '/upload/lib/cache/secache_.php',
    'filesize' => 20527,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/lib/cache.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/lib/cache.php',
    'remotepath' => '/upload/lib/cache.php',
    'filesize' => 1640,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/lib/fetch.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/lib/fetch.php',
    'remotepath' => '/upload/lib/fetch.php',
    'filesize' => 7988,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/lib/onedrive.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/lib/onedrive.php',
    'remotepath' => '/upload/lib/onedrive.php',
    'filesize' => 9421,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/lib/oneindex.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/lib/oneindex.php',
    'remotepath' => '/upload/lib/oneindex.php',
    'filesize' => 3838,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/lib/route.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/lib/route.php',
    'remotepath' => '/upload/lib/route.php',
    'filesize' => 3978,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/lib/sqlite.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/lib/sqlite.php',
    'remotepath' => '/upload/lib/sqlite.php',
    'filesize' => 2626,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/lib/view.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/lib/view.php',
    'remotepath' => '/upload/lib/view.php',
    'filesize' => 2277,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/one.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/one.php',
    'remotepath' => '/upload/one.php',
    'filesize' => 6168,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/admin/cache.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/admin/cache.php',
    'remotepath' => '/upload/view/admin/cache.php',
    'filesize' => 1977,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/admin/images.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/admin/images.php',
    'remotepath' => '/upload/view/admin/images.php',
    'filesize' => 1299,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/admin/install/install_0.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/admin/install/install_0.php',
    'remotepath' => '/upload/view/admin/install/install_0.php',
    'filesize' => 2264,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/admin/install/install_1.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/admin/install/install_1.php',
    'remotepath' => '/upload/view/admin/install/install_1.php',
    'filesize' => 2348,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/admin/install/install_2.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/admin/install/install_2.php',
    'remotepath' => '/upload/view/admin/install/install_2.php',
    'filesize' => 530,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/admin/install/install_3.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/admin/install/install_3.php',
    'remotepath' => '/upload/view/admin/install/install_3.php',
    'filesize' => 847,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/admin/install/layout.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/admin/install/layout.php',
    'remotepath' => '/upload/view/admin/install/layout.php',
    'filesize' => 2047,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/admin/layout.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/admin/layout.php',
    'remotepath' => '/upload/view/admin/layout.php',
    'filesize' => 3298,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/admin/login.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/admin/login.php',
    'remotepath' => '/upload/view/admin/login.php',
    'filesize' => 781,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/admin/setpass.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/admin/setpass.php',
    'remotepath' => '/upload/view/admin/setpass.php',
    'filesize' => 894,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/admin/settings.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/admin/settings.php',
    'remotepath' => '/upload/view/admin/settings.php',
    'filesize' => 3267,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/admin/show.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/admin/show.php',
    'remotepath' => '/upload/view/admin/show.php',
    'filesize' => 752,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/admin/upload.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/admin/upload.php',
    'remotepath' => '/upload/view/admin/upload.php',
    'filesize' => 3538,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/classic/404.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/classic/404.php',
    'remotepath' => '/upload/view/classic/404.php',
    'filesize' => 3116,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/classic/layout.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/classic/layout.php',
    'remotepath' => '/upload/view/classic/layout.php',
    'filesize' => 1595,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/classic/list.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/classic/list.php',
    'remotepath' => '/upload/view/classic/list.php',
    'filesize' => 4541,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/material/404.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/material/404.php',
    'remotepath' => '/upload/view/material/404.php',
    'filesize' => 195,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/material/images/index.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/material/images/index.php',
    'remotepath' => '/upload/view/material/images/index.php',
    'filesize' => 602,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/material/images/layout.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/material/images/layout.php',
    'remotepath' => '/upload/view/material/images/layout.php',
    'filesize' => 2087,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/material/layout.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/material/layout.php',
    'remotepath' => '/upload/view/material/layout.php',
    'filesize' => 2265,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/material/list.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/material/list.php',
    'remotepath' => '/upload/view/material/list.php',
    'filesize' => 5340,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/material/password.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/material/password.php',
    'remotepath' => '/upload/view/material/password.php',
    'filesize' => 839,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/material/show/audio.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/material/show/audio.php',
    'remotepath' => '/upload/view/material/show/audio.php',
    'filesize' => 1298,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/material/show/code.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/material/show/code.php',
    'remotepath' => '/upload/view/material/show/code.php',
    'filesize' => 1626,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/material/show/doc.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/material/show/doc.php',
    'remotepath' => '/upload/view/material/show/doc.php',
    'filesize' => 290,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/material/show/image.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/material/show/image.php',
    'remotepath' => '/upload/view/material/show/image.php',
    'filesize' => 954,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/material/show/pdf.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/material/show/pdf.php',
    'remotepath' => '/upload/view/material/show/pdf.php',
    'filesize' => 1193,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/material/show/stream.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/material/show/stream.php',
    'remotepath' => '/upload/view/material/show/stream.php',
    'filesize' => 2941,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/material/show/video.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/material/show/video.php',
    'remotepath' => '/upload/view/material/show/video.php',
    'filesize' => 1455,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/material/show/video2.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/material/show/video2.php',
    'remotepath' => '/upload/view/material/show/video2.php',
    'filesize' => 1571,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/material/show/video5.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/material/show/video5.php',
    'remotepath' => '/upload/view/material/show/video5.php',
    'filesize' => 956,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/nexmoe/404.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/nexmoe/404.php',
    'remotepath' => '/upload/view/nexmoe/404.php',
    'filesize' => 194,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/nexmoe/bj.jpg' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/nexmoe/bj.jpg',
    'remotepath' => '/upload/view/nexmoe/bj.jpg',
    'filesize' => 2989881,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/nexmoe/css/style.css' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/nexmoe/css/style.css',
    'remotepath' => '/upload/view/nexmoe/css/style.css',
    'filesize' => 2797,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/nexmoe/favicon.ico' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/nexmoe/favicon.ico',
    'remotepath' => '/upload/view/nexmoe/favicon.ico',
    'filesize' => 4286,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/nexmoe/images/index.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/nexmoe/images/index.php',
    'remotepath' => '/upload/view/nexmoe/images/index.php',
    'filesize' => 651,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/nexmoe/images/layout.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/nexmoe/images/layout.php',
    'remotepath' => '/upload/view/nexmoe/images/layout.php',
    'filesize' => 1176,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/nexmoe/js/urusai.js' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/nexmoe/js/urusai.js',
    'remotepath' => '/upload/view/nexmoe/js/urusai.js',
    'filesize' => 616,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/nexmoe/layout.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/nexmoe/layout.php',
    'remotepath' => '/upload/view/nexmoe/layout.php',
    'filesize' => 3944,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/nexmoe/list.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/nexmoe/list.php',
    'remotepath' => '/upload/view/nexmoe/list.php',
    'filesize' => 6917,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/nexmoe/password.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/nexmoe/password.php',
    'remotepath' => '/upload/view/nexmoe/password.php',
    'filesize' => 812,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/nexmoe/show/audio.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/nexmoe/show/audio.php',
    'remotepath' => '/upload/view/nexmoe/show/audio.php',
    'filesize' => 904,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/nexmoe/show/code.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/nexmoe/show/code.php',
    'remotepath' => '/upload/view/nexmoe/show/code.php',
    'filesize' => 1720,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/nexmoe/show/doc.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/nexmoe/show/doc.php',
    'remotepath' => '/upload/view/nexmoe/show/doc.php',
    'filesize' => 134,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/nexmoe/show/image.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/nexmoe/show/image.php',
    'remotepath' => '/upload/view/nexmoe/show/image.php',
    'filesize' => 995,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/nexmoe/show/pdf.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/nexmoe/show/pdf.php',
    'remotepath' => '/upload/view/nexmoe/show/pdf.php',
    'filesize' => 1193,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/nexmoe/show/stream.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/nexmoe/show/stream.php',
    'remotepath' => '/upload/view/nexmoe/show/stream.php',
    'filesize' => 2901,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/nexmoe/show/video.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/nexmoe/show/video.php',
    'remotepath' => '/upload/view/nexmoe/show/video.php',
    'filesize' => 1265,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/nexmoe/show/video2.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/nexmoe/show/video2.php',
    'remotepath' => '/upload/view/nexmoe/show/video2.php',
    'filesize' => 1614,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/nexmoe/show/video5.php' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/nexmoe/show/video5.php',
    'remotepath' => '/upload/view/nexmoe/show/video5.php',
    'filesize' => 979,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/nexmoe/urusai/urusai-1.ogg' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/nexmoe/urusai/urusai-1.ogg',
    'remotepath' => '/upload/view/nexmoe/urusai/urusai-1.ogg',
    'filesize' => 51952,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/nexmoe/urusai/urusai-2.ogg' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/nexmoe/urusai/urusai-2.ogg',
    'remotepath' => '/upload/view/nexmoe/urusai/urusai-2.ogg',
    'filesize' => 771970,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
  '/upload/view/nexmoe/urusai/urusai-3.ogg' => 
  array (
    'localfile' => '/home/vol6_6/epizy.com/epiz_24979812/shigatsuki.rf.gd/htdocs/view/nexmoe/urusai/urusai-3.ogg',
    'remotepath' => '/upload/view/nexmoe/urusai/urusai-3.ogg',
    'filesize' => 2393830,
    'upload_type' => 'web',
    'update_time' => 0,
  ),
);