<?php return array (
  'site_name' => '四月の库',
  'password' => '20030510.',
  'style' => 'nexmoe',
  'onedrive_root' => '/',
  'cache_type' => 'filecache',
  'cache_expire_time' => 360,
  'cache_refresh_time' => 600,
  'root_path' => '?',
  'show' => 
  array (
    'stream' => 
    array (
      0 => 'txt',
    ),
    'image' => 
    array (
      0 => 'bmp',
      1 => 'jpg',
      2 => 'jpeg',
      3 => 'png',
      4 => 'gif',
    ),
    'video5' => 
    array (
      0 => 'mp4',
      1 => 'webm',
      2 => 'mkv',
    ),
    'video' => 
    array (
      0 => '',
    ),
    'video2' => 
    array (
      0 => 'avi',
      1 => 'mpg',
      2 => 'mpeg',
      3 => 'rm',
      4 => 'rmvb',
      5 => 'mov',
      6 => 'wmv',
      7 => 'asf',
      8 => 'ts',
      9 => 'flv',
    ),
    'audio' => 
    array (
      0 => 'ogg',
      1 => 'mp3',
      2 => 'wav',
    ),
    'code' => 
    array (
      0 => 'html',
      1 => 'htm',
      2 => 'php',
      3 => 'css',
      4 => 'go',
      5 => 'java',
      6 => 'js',
      7 => 'json',
      8 => 'txt',
      9 => 'sh',
      10 => 'md',
    ),
    'doc' => 
    array (
      0 => 'csv',
      1 => 'doc',
      2 => 'docx',
      3 => 'odp',
      4 => 'ods',
      5 => 'odt',
      6 => 'pot',
      7 => 'potm',
      8 => 'potx',
      9 => 'pps',
      10 => 'ppsx',
      11 => 'ppsxm',
      12 => 'ppt',
      13 => 'pptm',
      14 => 'pptx',
      15 => 'rtf',
      16 => 'xls',
      17 => 'xlsx',
    ),
  ),
  'images' => 
  array (
    'home' => false,
    'public' => false,
    'exts' => 
    array (
      0 => 'jpg',
      1 => 'png',
      2 => 'gif',
      3 => 'bmp',
    ),
  ),
  'client_secret' => 'zlaGH(-;uivoVNPLJ00535(',
  'client_id' => 'd85792a7-b24e-4074-8a81-8e14ad85a135',
  'redirect_uri' => 'https://oneindex.github.io/',
  'refresh_token' => 'OAQABAAAAAABeAFzDwllzTYGDLh_qYbH8J8bXlVF-Dyhl5GKcbPBnTuagFCEA8C1xzRyewt0B-ooenuIDlqfA-GApGwCfr4JrSpiRsLVxWEBezKdbl7IIPrBNov0G8MfbG_DrXZyveb6lcnwZTjRM2FcYh5OBwqYDWT2D3rHfeCGJFlmqKcQL_SmnAPNN3E_YC6OtZXAjt5fZZ7WGxoY6DyD2RazB8OFqkey7JM4gX32BN8c0yq-fTCw7UQ00LsfpI0VqSstRKaIpfCpgBgdfV4mmuJHzS_hw96K0MIGQzAV3vOoZXTEuHob1F0Ny4yAwCEUsnv4GClEZ_K21e30scooVPSs0EYqH5_rUiZXqVV6K3JYNAuuRP3bZi2TSVn7IjkO0no6Flzv0hTMXZVXYfkozse76u67W6RcG9prsfzXkCxBlX2MCCYpuOucdcdzj7Ymv6CX1cNS3gUqVyH_kTMiHfYKB_-df5sjCA0JhF7dfksmzuhfmXAsjgYjCqAoLxjlFZfcgIegXMkKLYn-lIGe8aB4alYZVIvFWFhMjS3fw3Pyzy32MyeGeEsC9kBHCZQjiJ2K4Y6_XcvKghPtaCbxhBngNOYlOPZgDV1Hr3ycnDKTdMZVAnnHcrP3E9VKVFCJ1mqPALoEWwcKfWUdYW11vKStgnTLCkYyQkjFm8VECQMcTK9w4ypQLoCvPYVixHgiWhoHhmLVp5oTk_AoKeFu7qlUItsMUvxyaOKXRbvM4TuipnMBCyihGcNvBuNDnj10RRVE-hglnClbv41O3yL1CP6uRDZlcjAKCLf8gQqv8ynqmNcdo0nRrgwQ4I8lj-u5-E1k045i3-QKLyy9G_9zDRjqtb6sKIAA',
  'onedrive_hide' => '',
  'onedrive_hotlink' => '',
);