<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no"/>
	<title><?php e($title.' - '.config('site_name'));?></title>
	<link rel="stylesheet" href="//cdnjs.loli.net/ajax/libs/mdui/0.4.1/css/mdui.css">
	<style>
	._th_cover-all-show-times._th_hidden{display:none;}
		.mdui-container:after{
      background: #ffffff url(https://random.52ecy.cn/randbg.php) no-repeat;
			background-size:cover;
			content: "";
			display: block;
			z-index: -1;
			position: absolute;
			left:0;
			top:0;
			width: 100%;
			height: 100%;
			-webkit-filter:blur(8px);
			-ms-filter: blur(8px);
			filter: blur(8px);
		}
		html,body{
		width:100%;
		height:95%;
		}
.mdui-list::-webkit-scrollbar{
height:0px;
width:0px;
}
#cnzz_stat_icon_1278076176{
position:absolute;
right:0px;
bottom:0px;
opacity:0.3;
}
.mdui-container{width:100%;height:100%;}
		
		.top{height:50px;border-radius:5px;}
		.nexmoe-item{height:480px;width:330px;color:black;margin:40px auto;padding:15px!important;border-radius:5px;background-color:black;-webkit-box-shadow:0 .5em 3em rgba(161,177,204,.4);box-shadow:0 .5em 3em rgba(161,177,204,.4);background-color:rgba(255,255,255,0.5);}
		.mdui-img-fluid,.mdui-video-fluid{border-radius:5px;border:1px solid black}
		.mdui-list{padding:0;height:400px;overflow:auto;}
		.mdui-list-item{margin:0!important;border-radius:5px;padding:0 10px 0 5px!important;border:1px solid rgba(0,0,0,0);margin-bottom:10px!important}
		.mdui-list-item:last-child{margin-bottom:0!important}
		.mdui-list-item:first-child{border:none}
		.mdui-toolbar{width:auto;margin-top:60px!important}
		.mdui-appbar .mdui-toolbar{height:56px;font-size:12px}
		.mdui-container{max-width:980px}.mdui-list>.th{background-color:initial}
		.mdui-list-item>a{width:100%;line-height:15px}
		@media screen and (max-width:980px){.mdui-list-item .mdui-text-right{display:none}
		
	</style>
	<script src="//cdnjs.loli.net/ajax/libs/mdui/0.4.1/js/mdui.min.js"></script>
	<script src="https://v1.hitokoto.cn/?encode=js&select=%23hitokoto" defer></script>
	<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? "https://" : "http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1278076176'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "v1.cnzz.com/z_stat.php%3Fid%3D1278076176%26show%3Dpic' type='text/javascript'%3E%3C/script%3E"));</script>
</head>
<body class="mdui-theme-primary-blue-grey mdui-theme-accent-blue">
	<div class="mdui-container">
    	<?php view::section('content');?>
  	</div>
</body>
</html>