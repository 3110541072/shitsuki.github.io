<?php return array (
  'expire' => 1584115924,
  'data' => 
  array (
    '9a30813faf4a866abeb0ddfc04557024' => 
    array (
      'name' => '9a30813faf4a866abeb0ddfc04557024',
      'size' => 467556805,
      'lastModifiedDateTime' => 1581121719,
      'downloadUrl' => NULL,
      'folder' => true,
    ),
  ),
);