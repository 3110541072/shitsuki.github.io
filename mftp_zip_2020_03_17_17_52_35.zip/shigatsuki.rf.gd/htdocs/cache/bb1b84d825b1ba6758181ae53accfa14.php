<?php return array (
  'expire' => 1584115880,
  'data' => 
  array (
    'krkr' => 
    array (
      'name' => 'krkr',
      'size' => 20795105910,
      'lastModifiedDateTime' => 1581101438,
      'downloadUrl' => NULL,
      'folder' => true,
    ),
  ),
);