<?php return array (
  'expire' => 1584202466,
  'data' => 
  array (
    'GalGame' => 
    array (
      'name' => 'GalGame',
      'size' => 20795105910,
      'lastModifiedDateTime' => 1581101434,
      'downloadUrl' => NULL,
      'folder' => true,
    ),
    '漫画' => 
    array (
      'name' => '漫画',
      'size' => 2401159960,
      'lastModifiedDateTime' => 1581101437,
      'downloadUrl' => NULL,
      'folder' => true,
    ),
  ),
);